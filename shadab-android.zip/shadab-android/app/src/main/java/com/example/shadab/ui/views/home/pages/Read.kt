package com.example.shadab.ui.views.home.pages

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.shadab.Model

@Composable
fun Read(model: Model) {
    val context = LocalContext.current
    LazyColumn(
        modifier = Modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        items(model.reads.size) { index ->
            val read = model.reads[index]
            Card(
                modifier = Modifier.fillMaxWidth().height(120.dp),
                onClick = {
                    model.openWebPage(context, read.url)
                }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.weight(2f).padding(horizontal = 10.dp, vertical = 10.dp)
                    ) {
                        Text(read.title, style = MaterialTheme.typography.titleSmall)
                        Spacer(modifier = Modifier.height(5.dp))
                        Text(read.text, style = MaterialTheme.typography.bodySmall, overflow = TextOverflow.Ellipsis)
                    }
                    Image(
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        painter = painterResource(read.image),
                        contentDescription = null,
                        contentScale = ContentScale.Crop
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}