package com.example.shadab.ui.views.home.pages

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.shadab.Model
import com.example.shadab.R
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun User(model: Model) {
    val donePercentage = model.getDonePercentage()
    val animatedPercentage = animateFloatAsState(
        targetValue = donePercentage,
        animationSpec = tween(durationMillis = 500), label = ""
    ).value

    var name by remember { model.userName }
    var bio by remember { model.userBio }
    var profile by remember { model.userProfile }

    var nameInput by remember {
        mutableStateOf("")
    }

    var bioInput by remember {
        mutableStateOf("")
    }

    var dialog by remember {
        mutableStateOf(false)
    }

    LaunchedEffect(Unit) {
        nameInput = name
        bioInput = bio
        model.editeClicked = {
            dialog = true
        }
    }

    if (dialog) {
        Dialog(
            onDismissRequest = { dialog = false }
        ) {
            Card {
                Column(
                    modifier = Modifier.padding(
                        top = 25.dp,
                        start = 25.dp,
                        end = 25.dp,
                        bottom = 15.dp
                    )
                ) {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        text = "مشخصات خود را وارد کنید",
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    OutlinedTextField(
                        modifier = Modifier.fillMaxWidth(),
                        value = nameInput,
                        onValueChange = { value -> nameInput = value },
                        placeholder = {
                            Text("نام")
                        },
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    OutlinedTextField(
                        modifier = Modifier.fillMaxWidth(),
                        value = bioInput,
                        onValueChange = { value -> bioInput = value },
                        placeholder = {
                            Text("بیوگرافی")
                        },
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(model.profiles.size) { index ->
                            val userProfile = model.profiles[index]
                            Box(
                                modifier = Modifier
                                    .padding(5.dp).clip(CircleShape).clickable{
                                        model.setProfile(userProfile)
                                        profile = userProfile
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                Image(
                                    painter = painterResource(userProfile),
                                    contentDescription = null
                                )
                                if (profile == userProfile) {
                                    Image(
                                        modifier = Modifier.fillMaxSize().alpha(0.8f).background(Color.Gray),
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(15.dp))
                    Row {
                        TextButton(
                            onClick = {
                                model.setName(nameInput)
                                model.setBio(bioInput)
                                name = nameInput
                                bio = bioInput
                                dialog = false
                            }
                        ) {
                            Text("تایید")
                        }
                        TextButton(
                            onClick = {
                                dialog = false
                            }
                        ) {
                            Text("لغو")
                        }
                    }
                }
            }
        }
    }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            modifier = Modifier.clip(CircleShape).size(130.dp),
            painter = painterResource(profile),
            contentDescription = null
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            name,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            bio,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(40.dp))
        Row {
            Text("100%")
            Spacer(modifier = Modifier.width(10.dp))
            LinearProgressIndicator(
                modifier = Modifier
                    .weight(1f)
                    .height(30.dp)
                    .rotate(180f)
                    .clip(RoundedCornerShape(50.dp)),
                progress = animatedPercentage / 100,
                strokeCap = StrokeCap.Butt
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(" 0%  ")
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            "${animatedPercentage.roundToInt()}% کار ها رو انجام دادی",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.weight(1f))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(painter = painterResource(R.drawable.star), contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("مورد علاقه", modifier = Modifier.padding(vertical = 15.dp))
        }
        Spacer(
            modifier = Modifier
                .height(1.dp)
                .fillMaxWidth()
                .background(color = MaterialTheme.colorScheme.onPrimaryContainer)
                .alpha(0.1f)
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(painterResource(R.drawable.question), contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("سوالات متداول", modifier = Modifier.padding(vertical = 15.dp))
        }
        Spacer(
            modifier = Modifier
                .height(1.dp)
                .fillMaxWidth()
                .background(color = MaterialTheme.colorScheme.onPrimaryContainer)
                .alpha(0.1f)
        )
        Row(
            modifier = Modifier.fillMaxWidth().clickable{
                model.openWebPage(context, "https://survey.porsline.ir/s/D9lfBpN1")
            },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painterResource(R.drawable.contact),
                contentDescription = null
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("انتقادات و پیشنهادات", modifier = Modifier.padding(vertical = 15.dp))
        }
        Spacer(
            modifier = Modifier
                .height(1.dp)
                .fillMaxWidth()
                .background(color = MaterialTheme.colorScheme.onPrimaryContainer)
                .alpha(0.1f)
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painterResource(R.drawable.group_24dp_e8eaed_fill0_wght400_grad0_opsz24),
                contentDescription = null
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("درباره ما", modifier = Modifier.padding(vertical = 15.dp))
        }
        Spacer(
            modifier = Modifier
                .height(1.dp)
                .fillMaxWidth()
                .background(color = MaterialTheme.colorScheme.onPrimaryContainer)
                .alpha(0.1f)
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(painterResource(R.drawable.exit), contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("خروج", modifier = Modifier.padding(vertical = 15.dp))
        }
        Spacer(modifier = Modifier.height(30.dp))
    }
}
