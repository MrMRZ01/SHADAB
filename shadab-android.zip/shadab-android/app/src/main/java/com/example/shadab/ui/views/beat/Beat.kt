package com.example.shadab.ui.views.beat
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.shadab.Model
import com.example.shadab.ui.nav.Destinations
import java.util.concurrent.Executors
import com.example.shadab.R
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Beat(model: Model) {
    val context = LocalContext.current
    val heartRate = remember { mutableStateOf(70) }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    var dialog by remember {
        mutableStateOf(false)
    }

    LaunchedEffect(Unit) {
        val handler = Handler(Looper.getMainLooper())
        val random = java.util.Random()
        handler.post(object : Runnable {
            override fun run() {
                heartRate.value = 60 + random.nextInt(40)
                if (dialog == false) {
                    handler.postDelayed(this, 1000)
                }
            }
        })
        delay(10000)
        dialog = true
    }



    if (dialog) {
        Dialog(
            onDismissRequest = {
                dialog = false
                model.nav.navigate(Destinations.Main.route)
            }
        ) {
            Card() {
                Column(
                    modifier = Modifier.padding(
                        top = 25.dp,
                        start = 25.dp,
                        end = 25.dp,
                        bottom = 15.dp
                    )
                ) {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        text = "ضربان قلب شما ${heartRate.value} ضرب بر دقیقه محاسبه شد",
                        textAlign = TextAlign.Center
                    )

                    Row {
                        TextButton(
                            onClick = {
                                model.nav.navigate(Destinations.Main.route)
                            }
                        ) {
                            Text("تایید")
                        }
                    }
                }
            }
        }
    }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        TopAppBar(
            title = {
                Text("فشار خون")
            },
            actions = {
                IconButton(onClick = { model.nav.navigate(Destinations.Main.route) }) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = null)
                }
            }
        )
        Box(modifier = Modifier.fillMaxSize()) {
            CameraPreview(context, cameraExecutor)
            Column(modifier = Modifier.align(Alignment.BottomCenter), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(modifier = Modifier.size(40.dp), painter = painterResource(R.drawable.heart_beat), contentDescription = null, tint = Color.Red)
                Text(
                    text = "ضربان قلب بر دقیقه: ${heartRate.value}",
                    fontSize = 20.sp,
                    color = Color.Red,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 25.dp)
                )
            }
        }
    }
}

@Composable
fun CameraPreview(context: Context, cameraExecutor: java.util.concurrent.ExecutorService) {
    val lifecycleOwner = LocalLifecycleOwner.current

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            val previewView = PreviewView(ctx)

            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()

                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }

                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                val camera = cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview
                )

                // Enable the flashlight
                camera.cameraControl.enableTorch(true)

            }, ContextCompat.getMainExecutor(ctx))

            previewView
        }
    )
}

