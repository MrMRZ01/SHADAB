package com.example.shadab.ui.views.welcome

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.shadab.Model
import com.example.shadab.R
import com.example.shadab.ui.nav.Destinations

@Composable
fun Welcome(model: Model) {
    Column(
        modifier = Modifier.fillMaxSize()
            .padding(horizontal = 25.dp).statusBarsPadding().navigationBarsPadding(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.weight(1f))
        Image(
            modifier = Modifier
                .size(200.dp).padding(end = 40.dp),
            painter = painterResource(R.drawable.logo),
            contentDescription = null,
            contentScale = ContentScale.Inside
        )
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            "اپلیکیشن شاداب",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            "اپلیکیشن شاداب یک ابزار جامع و تعاملی برای بهبود سبک زندگی کاربران است که ابزار هایی مثل تشخیص ضربان قلب، محاسبه BMI و قدم شمار را نیز چاشنی کار خود کرده",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.weight(1f))
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                model.nav.navigate(Destinations.Main.route)
            }
        ) {
            Text(
                modifier = Modifier.padding(vertical = 3.dp),
                text = "شروع شاداب"
            )
        }
        Spacer(modifier = Modifier.height(20.dp))
    }
}