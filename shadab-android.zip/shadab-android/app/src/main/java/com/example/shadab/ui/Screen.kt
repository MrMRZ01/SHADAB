package com.example.shadab.ui

import android.os.Bundle
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import com.example.shadab.Model
import com.example.shadab.ui.nav.Nav
import com.example.shadab.ui.theme.Theme

@Composable
fun Screen(model: Model) {
    var current by remember {
        mutableStateOf("")
    }
    LaunchedEffect(Unit) {
        model.nav.addOnDestinationChangedListener(object :
            NavController.OnDestinationChangedListener {
            override fun onDestinationChanged(
                controller: NavController,
                destination: NavDestination,
                arguments: Bundle?
            ) {
                destination.route?.let {
                    current = destination.route.toString()
                }
            }
        })
    }
    Theme {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface {
                Box(
                    modifier = Modifier
                        .fillMaxSize().statusBarsPadding().navigationBarsPadding()
                ) {
                    Nav(model)
                }
            }
        }
    }
}