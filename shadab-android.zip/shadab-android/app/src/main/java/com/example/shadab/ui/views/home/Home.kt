package com.example.shadab.ui.views.home

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.shadab.Model
import com.example.shadab.R
import com.example.shadab.ui.views.home.pages.Kits
import com.example.shadab.ui.views.home.pages.Read
import com.example.shadab.ui.views.home.pages.Step
import com.example.shadab.ui.views.home.pages.Todos
import com.example.shadab.ui.views.home.pages.User

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Home(model: Model) {
    var page by remember {
        mutableIntStateOf(2)
    }
    val state = rememberPagerState { 5 }
    LaunchedEffect(page) {
        state.animateScrollToPage(page)
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        TopAppBar(
            title = {
                Text(if (page == 0) "پروفایل" else if (page == 1) "لیست کارها" else if (page == 2) "ابزار ها" else if (page == 3) "قدم شمار" else if (page == 4) "مقاله ها" else "")
            },
            actions = {
                if (page == 0) {
                    IconButton(
                        onClick = {
                            model.editeClicked?.invoke()
                        }
                    ) {
                        Icon(Icons.Outlined.Edit, contentDescription = null)
                    }
                }
            }
        )
        HorizontalPager(
            modifier = Modifier.weight(1f).padding(horizontal = 20.dp),
            state = state,
            userScrollEnabled = false
        ) {
            if (page == 0) {
                User(model)
            }
            if (page == 1) {
                Todos(model)
            }
            if (page == 2) {
                Kits(model)
            }
            if (page == 3) {
                Step(model)
            }
            if (page == 4) {
                Read(model)
            }
        }
        BottomAppBar(
            modifier = Modifier
                .height(60.dp)
                .fillMaxWidth(),
            actions = {
                Spacer(modifier = Modifier.weight(1f))
                IconToggleButton(
                    checked = page == 0,
                    onCheckedChange = { toggle ->
                        if (toggle) {
                            page = 0
                        }
                    },
                ) {
                    Icon(
                        painterResource(R.drawable.user),
                        contentDescription = null
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                IconToggleButton(
                    checked = page == 1,
                    onCheckedChange = { toggle ->
                        if (toggle) {
                            page = 1
                        }
                    },
                ) {
                    Icon(
                        painterResource(R.drawable.todo),
                        contentDescription = null
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                IconToggleButton(
                    checked = page == 2,
                    onCheckedChange = { toggle ->
                        if (toggle) {
                            page = 2
                        }
                    },
                ) {
                    Icon(
                        painterResource(R.drawable.kit),
                        contentDescription = null
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                IconToggleButton(
                    checked = page == 3,
                    onCheckedChange = { toggle ->
                        if (toggle) {
                            page = 3
                        }
                    },
                ) {
                    Icon(
                        painterResource(R.drawable.walk),
                        contentDescription = null
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                IconToggleButton(
                    checked = page == 4,
                    onCheckedChange = { toggle ->
                        if (toggle) {
                            page = 4
                        }
                    },
                ) {
                    Icon(
                        painter = painterResource(R.drawable.article),
                        contentDescription = null
                    )
                }
                Spacer(modifier = Modifier.weight(1f))

            }
        )
    }
}


