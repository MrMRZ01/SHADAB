package com.example.shadab.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.shadab.Model
import com.example.shadab.ui.views.beat.Beat
import com.example.shadab.ui.views.bmi.Bmi
import com.example.shadab.ui.views.home.Home
import com.example.shadab.ui.views.sight.Sight
import com.example.shadab.ui.views.welcome.Welcome

@Composable
fun Nav(model: Model) {
    NavHost(model.nav, startDestination = Destinations.Welcome.route) {
        composable(Destinations.Welcome.route) {
            Welcome(model)
        }
        composable(Destinations.Main.route) {
            Home(model)
        }
        composable(Destinations.Bmi.route) {
            Bmi(model)
        }
        composable(Destinations.Sight.route) {
            Sight(model)
        }
        composable(Destinations.Beat.route) {
            Beat(model)
        }
    }
}