package com.example.shadab.ui.nav

sealed class Destinations(
    val name: String,
    val route: String
) {
    object Welcome: Destinations("Welcome", "welcome")
    object Main: Destinations("Main", "main")
    object Bmi: Destinations("Bmi", "bmi")
    object Sight: Destinations("Sight", "sight")
    object Beat: Destinations("Beat", "beat")

}