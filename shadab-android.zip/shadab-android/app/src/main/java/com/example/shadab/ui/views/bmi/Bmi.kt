package com.example.shadab.ui.views.bmi

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.shadab.Model
import com.example.shadab.ui.nav.Destinations
import com.example.shadab.ui.views.sentence.Sentence
import kotlin.math.pow
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Bmi(model: Model) {
    var height by remember { mutableIntStateOf(100) }
    var weight by remember { mutableIntStateOf(75) }
    val bmi: Double = if (height > 0 && weight > 0) {
        weight / (height / 100.0).pow(2)
    } else {
        0.0
    }

    val status = when {
        bmi < 18.5 -> "کم‌وزن"
        bmi < 24.9 -> "طبیعی"
        bmi < 29.9 -> "اضافه وزن"
        else -> "چاق"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        TopAppBar(
            title = {
                Text("کنترل وزن")
            },
            actions = {
                IconButton(
                    onClick = {
                        model.nav.navigate(Destinations.Main.route)
                    }
                ) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = null)
                }
            }
        )

        Column(
            modifier = Modifier.padding(horizontal = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("وزن", style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("$weight", style = MaterialTheme.typography.titleLarge)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            "کیلوگرم",
                            style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Card(
                            onClick = { weight++ }
                        ) {
                            Icon(
                                modifier = Modifier.padding(5.dp),
                                imageVector = Icons.Default.KeyboardArrowUp,
                                contentDescription = null
                            )
                        }
                        Spacer(modifier = Modifier.width(15.dp))
                        Card(
                            onClick = { if (weight > 0) weight-- }
                        ) {
                            Icon(
                                modifier = Modifier.padding(5.dp),
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = null
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("قد", style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(height.toString(), style = MaterialTheme.typography.titleLarge)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            "سانتی متر",
                            style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic)
                        )
                    }
                    Slider(
                        value = height.toFloat(),
                        onValueChange = { value -> height = value.roundToInt() },
                        valueRange = 100f..300f
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))


            Text(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                text = "نتیجه:",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.headlineLarge
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("BMI")
                    Text(
                        modifier = Modifier,
                        text = "%.1f".format(bmi),
                        style = MaterialTheme.typography.headlineLarge.copy(fontStyle = FontStyle.Italic)
                    )
                }
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("وضعیت")
                    Text(
                        modifier = Modifier,
                        text = status,
                        style = MaterialTheme.typography.headlineLarge.copy(fontStyle = FontStyle.Italic)
                    )
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            Sentence(model.foodPics)
            Spacer(modifier = Modifier.weight(1f))
            Column(
                modifier = Modifier.fillMaxWidth().padding(bottom = 25.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color.Cyan)
                ) {
                    Text(
                        text = "< 18.5: کم‌وزن",
                        modifier = Modifier.padding(10.dp).fillMaxSize(),
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color.Green),
                ) {
                    Text(
                        text = "18.5 - 24.9: طبیعی",
                        modifier = Modifier.padding(10.dp).fillMaxSize(),
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color.Yellow)
                ) {
                    Text(
                        text = "25.0 - 29.9: اضافه وزن",
                        modifier = Modifier.padding(10.dp).fillMaxSize(),
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color.Red)
                ) {
                    Text(
                        text = ">= 30.0: چاق",
                        modifier = Modifier.padding(10.dp).fillMaxSize(),
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
