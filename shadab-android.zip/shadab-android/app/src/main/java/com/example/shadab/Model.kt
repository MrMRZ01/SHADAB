package com.example.shadab

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.navigation.NavHostController
import com.example.shadab.ui.nav.Destinations
import org.json.JSONException
import org.json.JSONObject

class Model(val context: Context) {
    lateinit var nav: NavHostController
    private val todosPref = context.getSharedPreferences("todos", Context.MODE_PRIVATE)
    private val userPref = context.getSharedPreferences("user", Context.MODE_PRIVATE)
    var todos = mutableStateListOf<Todo>()
    var userName = mutableStateOf(getName())
    var userBio = mutableStateOf(getBio())
    var userProfile = mutableStateOf(getProfile())
    var editeClicked: (() -> Unit)? = null

    private fun fillTodos() {
        val todosList = todosPref.all.mapNotNull { entry ->
            val title = entry.key
            val data = entry.value as? String ?: return@mapNotNull null
            try {
                val json = JSONObject(data)
                val done = json.getBoolean("done")
                val timestamp = json.getLong("timestamp")
                Todo(title, done, timestamp)
            } catch (e: JSONException) {
                null
            }
        }.sortedWith(compareBy<Todo> { it.done }
            .thenByDescending { it.timestamp })

        todos.clear()
        todos.addAll(todosList.map { Todo(it.title, it.done, it.timestamp) })
    }

    fun getDonePercentage(): Float {
        val totalTodos = todos.size
        if (totalTodos == 0) return 0f

        val doneTodos = todos.count { it.done }
        return (doneTodos.toFloat() / totalTodos) * 100
    }

    fun addTodo(title: String, done: Boolean) {
        val timestamp = System.currentTimeMillis()
        val todoData = "{\"done\":$done,\"timestamp\":$timestamp}"
        todosPref.edit().putString(title, todoData).apply()
        fillTodos()
    }

    fun deleteTodo(title: String) {
        todosPref.edit().remove(title).apply()
    }

    fun getName(): String {
        return userPref.getString("name", "کاربر مهمان").toString()
    }

    fun setName(name: String) {
        userPref.edit().putString("name", name).apply()
    }

    fun getProfile(): Int {
        return userPref.getInt("profile", R.drawable.profile6)
    }

    fun setProfile(profile: Int) {
        userPref.edit().putInt("profile", profile).apply()
    }

    fun getBio(): String {
        return userPref.getString("bio", "شاداب اپ تندرستی و سلامتی برای همه").toString()
    }

    fun setBio(bio: String) {
        userPref.edit().putString("bio", bio).apply()
    }

    val todosListener = object : SharedPreferences.OnSharedPreferenceChangeListener {
        override fun onSharedPreferenceChanged(
            sharedPreferences: SharedPreferences?,
            key: String?
        ) {
            fillTodos()
            userName.value = getName()
            userBio.value = getBio()
            userProfile.value = getProfile()
        }
    }

    val profiles = listOf(
        R.drawable.profile1,
        R.drawable.profile2,
        R.drawable.profile3,
        R.drawable.profile4,
        R.drawable.profile5,
        R.drawable.profile6,
        R.drawable.profile7,
        R.drawable.profile8,
    )

    init {
        fillTodos()
        todosPref.registerOnSharedPreferenceChangeListener(todosListener)
        userName.value = getName()
        userBio.value = getBio()
        userProfile.value = getProfile()
    }

    data class Todo(
        val title: String,
        val done: Boolean,
        val timestamp: Long
    )

    data class Kit(
        val title: String,
        val items: List<KitItems>,
        val pics: List<Int>? = null
    )

    data class KitItems(
        val title: String,
        val route: String?,
        val url: String?,
        val icon: Int
    )

    val childPic = listOf(
        R.drawable.child1,
        R.drawable.child2,
        R.drawable.child3,
        R.drawable.child4,
        R.drawable.child5,
        R.drawable.child6,
    )

    val monthPic = listOf(
        R.drawable.month1,
        R.drawable.month2,
        R.drawable.month3,
        R.drawable.month4,
    )

    val gymPic = listOf(
        R.drawable.gym1,
        R.drawable.gym2,
        R.drawable.gym3,
        R.drawable.gym4,
        R.drawable.gym5,
    )

    val psyPics = listOf(
        R.drawable.psy1,
        R.drawable.psy2,
        R.drawable.psy3,
        R.drawable.psy4,
    )

    val foodPics = listOf(
        R.drawable.food1,
        R.drawable.food2,
        R.drawable.food3,
        R.drawable.food4,
        R.drawable.food5,
    )

    val kits = listOf(
        Kit(
            "پایش سلامت",
            listOf(
                KitItems("ضربان قلب", Destinations.Beat.route, null, R.drawable.heart_beat),
                KitItems("فشار خون", null, null, R.drawable.blood_pressure),
                KitItems("تست شنوایی", null, null, R.drawable.hearing_test),
                KitItems("تست بینایی", Destinations.Sight.route, null, R.drawable.eye_test),
                KitItems("سلامت روان", null, "https://haal.ir/psychological-test/", R.drawable.psychology_test),
                KitItems("آزمایش پزشکی", null, "https://haal.ir/ai-doctor/", R.drawable.med_test),
                KitItems("چکاپ", null, null, R.drawable.checkup_test),
                KitItems("قند خون", null, null, R.drawable.blood_suger),
                KitItems("کنترل وزن", Destinations.Bmi.route, null, R.drawable.weight),
                KitItems("ارزش‌گذاری غذایی", null, null, R.drawable.food),
                KitItems("گروه‌های غذایی", null, null, R.drawable.food_amount)
            )
        ),
        Kit(
            "مشاوره",
            listOf(
                KitItems("پزشکیی", null, "https://haal.ir/online-medical-advice/", R.drawable.doctor),
                KitItems("ورزشی", null, "https://matchadiet.com/?gad_source=1&gclid=CjwKCAiAjeW6BhBAEiwAdKltMrOiVdNPZPaBhN1daFTAElF0LR6f5eikfg4T2OmHxDt7t0QuSHg2RRoCWpIQAvD_BwE", R.drawable.gym),
                KitItems("روانشناسی", null, "https://haal.ir/online-psychological-counseling/", R.drawable.psychology)
            ),
            psyPics
        ),
        Kit(
            "فروشگاه",
            listOf(
                KitItems("لوازم ورزشی", null, "https://gishasport.com/", R.drawable.gym_equ),
                KitItems("داروهای خانگی", null, "https://www.darooyab.ir/", R.drawable.medication),
                KitItems("لوازم پزشکی", null, null, R.drawable.med_equ),
                KitItems("پرستاری", null, "https://haal.ir/at-home-medical-services/", R.drawable.heart_plus),
                KitItems("آزمایش پزشکی", null, "https://haal.ir/at-home-tests/", R.drawable.labs)
            )
        ),
        Kit(
            "ورزش",
            listOf(
                KitItems("ورزش روزانه", null, "https://www.digikala.com/mag/%D9%88%D8%B1%D8%B2%D8%B4-%D8%AE%D8%A7%D9%86%D9%87-%D9%84%D8%A7%D8%BA%D8%B1%DB%8C-%D8%B4%DA%A9%D9%85-%D8%AA%D9%86%D8%A7%D8%B3%D8%A8-%D8%A7%D9%86%D8%AF%D8%A7%D9%85/", R.drawable.fitness),
                KitItems("حرکات اصلاحی", null, "https://malltina.com/mag/%D8%A8%D9%87%D8%AA%D8%B1%DB%8C%D9%86-%D8%AD%D8%B1%DA%A9%D8%A7%D8%AA-%D9%88%D8%B1%D8%B2%D8%B4%DB%8C-%D8%A8%D8%B1%D8%A7%DB%8C-%DA%A9%D8%A7%D8%B1%D9%85%D9%86%D8%AF%D8%A7%D9%86/", R.drawable.airline),
                KitItems("مشاغل سخت", null, null, R.drawable.work),
                KitItems("بازی‌های سالم", null, null, R.drawable.esports)
            ),
            gymPic
        ),
        Kit(
            "عادت ماهیانه",
            listOf(
                KitItems("مشاهده سریال", null, "https://www.aparat.com/movies", R.drawable.movie),
                KitItems("مقالات", null, "https://herlifeapp.com/blog/category/menstrual-cycle/period", R.drawable.library),
                KitItems("سوالات", null, "https://www.drnematolahi.com/NewsDetails.aspx?id=2404", R.drawable.contact),
                KitItems("شیر خوردن", null, null, R.drawable.grocery),
                KitItems("شریک من", null, null, R.drawable.partner),
                KitItems("سیکل پریود", null, "https://myladypads.com/period-tracker/#:~:text=%D8%A8%D8%B1%D8%A7%DB%8C%20%D9%85%D8%AD%D8%A7%D8%B3%D8%A8%D9%87%20%D8%B3%DB%8C%DA%A9%D9%84%20%D9%82%D8%A7%D8%B9%D8%AF%DA%AF%DB%8C%20%D8%AE%D9%88%D8%AF,%D8%B3%DB%8C%DA%A9%D9%84%20%D9%85%D8%A7%D9%87%D8%A7%D9%86%D9%87%20%DA%86%D8%B1%D8%AE%D9%87%20%D9%BE%D8%B1%DB%8C%D9%88%D8%AF%20%D8%B4%D9%85%D8%A7%D8%B3%D8%AA", R.drawable.bloodtype)
            ),
            monthPic
        ),
        Kit(
            "فرزندم",
            listOf(
                KitItems("بازی", null, "https://www.google.com/amp/s/mehrparvar.com/games-for-children-at-home/amp/", R.drawable.extension),
                KitItems("فیلم‌ها", null, "https://www.aparatkids.com/", R.drawable.live),
                KitItems("خرید سیسمونی", null, null, R.drawable.child_friendly),
                KitItems("والدین", null, null, R.drawable.family_restroom),
                KitItems("آلبوم خاطرات", null, null, R.drawable.person_book),
                KitItems("خرید اسباب بازی", null, null, R.drawable.toys),
                KitItems("دانستی‌های مادری", null, "https://radiokodak.com/article/1428/40-%D9%86%DA%A9%D8%AA%D9%87-%DB%8C-%DA%A9%D9%84%DB%8C%D8%AF%DB%8C-%DA%A9%D9%87-%D9%87%D8%B1-%D9%85%D8%A7%D8%AF%D8%B1-%D8%AA%D8%A7%D8%B2%D9%87-%D8%A7%DB%8C-%D8%A8%D8%A7%DB%8C%D8%AF-%D8%A8%D8%AF%D8%A7%D9%86%D8%AF", R.drawable.baby_changing)
            ),
            childPic
        )
    )

    data class Read(
        val title: String,
        val text: String,
        val image: Int,
        val url: String
    )

    val reads = listOf(
        Read(
            "آیا پیاده روی بر لاغری مؤثر است؟",
            "پیاده روی یک فعالیت بسیار مفید برای لاغری شکم و کاهش وزن بدن است. این ورزش نیازی به تجهیزات خاصی ندارد و به راحتی قابل انجام است. پیاده روی نه تنها به کاهش وزن کمک می\u200C کند بلکه مزایای سلامتی دیگری نیز دارد.",
            R.drawable.read1,
            "https://beh-tavan.com/%d8%a2%db%8c%d8%a7-%d9%be%db%8c%d8%a7%d8%af%d9%87-%d8%b1%d9%88%db%8c-%d9%84%d8%a7%d8%ba%d8%b1%db%8c-%d8%aa%d8%a7%d8%ab%db%8c%d8%b1-%d8%af%d8%a7%d8%b1%d8%af/"
        ),
        Read(
            "نحوه خواندن فشار خون از روی دستگاه",
            "اگر فشارخون دارید بهتر است با نحوه خواندن فشار خون با دستگاه فشارسنج آشنا شوید. گرفتن فشار خون یک فرآیند مهم و حیاتی برای مراقبت از سلامتی افراد است. این فرآیند معمولاً توسط پزشکان، پرستاران، یا افراد خانگی به منظور نظارت بر وضعیت سلامت قلب و عروق انجام می \u200Cشود.",
            R.drawable.read2,
            "https://beh-tavan.com/%d8%ae%d9%88%d8%a7%d9%86%d8%af%d9%86-%d9%81%d8%b4%d8%a7%d8%b1-%d8%ae%d9%88%d9%86-%d8%af%d8%b3%d8%aa%da%af%d8%a7%d9%87-%d9%81%d8%b4%d8%a7%d8%b1%d8%b3%d9%86%d8%ac/"
        ),
        Read(
            "اهمیت واکسن آنفولانزا",
            "آنفولانزا یکی از بیماری\u200Cهای شایع و ویروسی است که با علائمی مانند تب، سردرد، خستگی، درد عضلانی، سرفه و گلودرد همراه است. این بیماری معمولاً در فصل\u200Cهای سرد سال شیوع پیدا می\u200Cکند و به راحتی از فردی به فرد دیگر منتقل می\u200Cشود.",
            R.drawable.read3,
            "https://hammdam.com/%d8%aa%d8%b2%d8%b1%db%8c%d9%82-%d9%88%d8%a7%da%a9%d8%b3%d9%86-%d8%a7%d9%86%d9%81%d9%88%d9%84%d8%a7%d9%86%d8%b2%d8%a7/"
        ),
        Read(
            "چه خوراکی هایی رو با معده خالی نخوریم؟",
            "همه ما می دانیم که صبحانه مهمترین وعده غذایی است . اما چه خوراکی هایی را نباید با معده خالی مصرف کرد:",
            R.drawable.read4,
            "https://www.koushanpharmed.com/%d8%a7%d8%b2-%d9%85%d8%b5%d8%b1%d9%81-%da%86%d9%87-%d8%ae%d9%88%d8%b1%d8%a7%da%a9%db%8c-%d9%87%d8%a7%db%8c%db%8c-%d8%a8%d8%a7-%d9%85%d8%b9%d8%af%d9%87-%d8%ae%d8%a7%d9%84%db%8c-%d8%a7%d8%ac%d8%aa%d9%86/"
        ),
        Read(
            "چرخه پریود و تأثیرات آن بر پوست و مو",
            "روزهای پریود و چند روز پیش از آن که همراه با تغییرات روحی و دردهای جسمی است به میزان کافی سخت هستند چه برسد به اضافه شدن تغییرات پوست و مو، گاهی حتی فکر کردن به تغییرات پوست و مو ما را به هم می\u200Cریزد. ",
            R.drawable.read5,
            "https://herlifeapp.com/blog/articles/skin-and-hair#:~:text=%D8%A7%D9%85%D8%A7%20%D9%85%D8%A7%D8%AC%D8%B1%D8%A7%20%D8%A7%D8%B2%20%DA%86%D9%87%20%D9%82%D8%B1%D8%A7%D8%B1%20%D8%A7%D8%B3%D8%AA%D8%9F&text=%D9%82%D8%B5%D9%87%20%D8%A7%DB%8C%D9%86%20%D8%A7%D8%B3%D8%AA%20%DA%A9%D9%87%20%D8%AA%D9%88%D9%84%DB%8C%D8%AF,%D9%88%20%D8%B1%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C%20%D8%A8%D9%87%20%D9%86%D8%B8%D8%B1%20%D8%A8%D8%B1%D8%B3%D8%AF"
        )
    )

    fun openWebPage(context: Context, url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        context.startActivity(intent)
    }
}