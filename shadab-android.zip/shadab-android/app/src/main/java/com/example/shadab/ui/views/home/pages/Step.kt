package com.example.shadab.ui.views.home.pages

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.shadab.Model
import kotlin.math.roundToInt

@Composable
fun Step(model: Model) {
    val context = LocalContext.current
    val goal = 10000
    var steps by remember { mutableIntStateOf(0) }

    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

    DisposableEffect(Unit) {
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event?.sensor?.type == Sensor.TYPE_STEP_COUNTER) {
                    steps = event.values[0].toInt()
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        sensorManager.registerListener(listener, stepSensor, SensorManager.SENSOR_DELAY_UI)

        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }

    val progress = (steps / goal.toFloat()).coerceIn(0f, 1f)
    val percentage = (progress * 100).roundToInt()

    Column(
        modifier = Modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "قدم ها", fontSize = 24.sp, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(10.dp))
        Text(text = "$goal / $steps", fontSize = 20.sp, textAlign = TextAlign.Center)

        Spacer(modifier = Modifier.height(16.dp))
        LinearProgressIndicator(
            progress = progress,
            modifier = Modifier
                .fillMaxWidth()
                .height(30.dp)
                .rotate(180f)
                .clip(RoundedCornerShape(50.dp)),
        )

        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "$percentage%", fontSize = 18.sp, textAlign = TextAlign.Center)

        Spacer(modifier = Modifier.height(32.dp))
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(text = "کالری مصرف شده:", fontSize = 16.sp)
            Spacer(modifier = Modifier.weight(1f))
            Row(verticalAlignment = Alignment.Bottom) {
                Text("کیلوکالری", fontStyle = FontStyle.Italic, fontSize = 12.sp)
                Spacer(modifier = Modifier.width(2.dp))
                Text("${calculateCalories(steps)}", fontSize = 30.sp, fontStyle = FontStyle.Italic)
            }
        }
        Spacer(modifier = Modifier.height(15.dp))
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(text = "معادل:", fontSize = 16.sp)
            Spacer(modifier = Modifier.weight(1f))
            Row(verticalAlignment = Alignment.Bottom) {
                Text("کیلومتر", fontStyle = FontStyle.Italic, fontSize = 12.sp)
                Spacer(modifier = Modifier.width(2.dp))
                Text("${calculateDistance(steps)}", fontSize = 30.sp, fontStyle = FontStyle.Italic)
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Column(modifier = Modifier.padding(bottom = 26.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "1403/09/21", fontSize = 14.sp)
                Text(text = "9624 قدم", fontSize = 14.sp)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "1403/09/21", fontSize = 14.sp)
                Text(text = "2322 قدم", fontSize = 14.sp)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "1403/09/21", fontSize = 14.sp)
                Text(text = "4533 قدم", fontSize = 14.sp)
            }
        }
    }
}

private fun calculateCalories(steps: Int): Int {
    return (steps * 0.05).roundToInt()
}

private fun calculateDistance(steps: Int): Double {
    return (steps * 0.08).roundToInt() / 1000.0
}
