package com.example.shadab.ui.views.home.pages

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.shadab.Model
import com.example.shadab.ui.views.sentence.Sentence

@Composable
fun Kits(model: Model) {
    val context = LocalContext.current
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        modifier = Modifier
            .fillMaxSize(),
    ) {
        model.kits.forEach { kit ->
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    text = kit.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    style = MaterialTheme.typography.titleMedium
                )
            }
            items(kit.items.size) { index ->
                val item = kit.items[index]
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                        onClick = {
                            if (item.route != null) {
                                model.nav.navigate(item.route)
                            }
                            if (item.url != null) {
                                model.openWebPage(context, item.url)
                            }
                        },
                        modifier = Modifier.aspectRatio(1f),
                    ) {
                        Icon(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(15.dp),
                            painter = painterResource(item.icon),
                            contentDescription = null
                        )
                    }
                    Text(
                        text = item.title,
                        modifier = Modifier
                            .padding(top = 5.dp)
                            .fillMaxWidth(),
                        style = MaterialTheme.typography.bodySmall,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }
            }
            kit.pics?.let {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Sentence(pics = kit.pics)
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}