package com.example.shadab.ui.views.sight

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.shadab.Model
import com.example.shadab.ui.nav.Destinations
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Sight(model: Model) {

    var dialog by remember {
        mutableStateOf(false)
    }

    val rotationList = listOf(0f, 90f, 180f, 270f)
    var rotation by remember { mutableStateOf(rotationList.random()) }
    var question by remember { mutableIntStateOf(1) }
    var questionColors = remember {
        mutableStateListOf(
            Color.Gray,
            Color.Gray,
            Color.Gray,
            Color.Gray,
            Color.Gray,
            Color.Gray
        )
    }
    var correctAnswers by remember { mutableStateOf(0) }

    fun handleAnswer(isCorrect: Boolean) {
        if (isCorrect) {
            correctAnswers += 1
        }
        questionColors[question - 1] = if (isCorrect) Color.Green else Color.Red
        if (question < 6) {
            rotation = rotationList.random()
            if (!isCorrect) {
                question++ // Move to the next question even if the answer is incorrect
            } else {
                question++
            }
        } else if (question == 6) {
            dialog = true
        }
    }

    if (dialog) {
        Dialog(
            onDismissRequest = {
                dialog = false
                model.nav.navigate(Destinations.Main.route)
            }
        ) {
            Card() {
                Column(
                    modifier = Modifier.padding(
                        top = 25.dp,
                        start = 25.dp,
                        end = 25.dp,
                        bottom = 15.dp
                    )
                ) {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        text = "نمره تست شما ${correctAnswers} از 6 می باشد",
                        textAlign = TextAlign.Center
                    )

                    Row {
                        TextButton(
                            onClick = {
                                model.nav.navigate(Destinations.Main.route)
                            }
                        ) {
                            Text("تایید")
                        }
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        TopAppBar(
            title = {
                Text("تست بینایی")
            },
            actions = {
                IconButton(onClick = { model.nav.navigate(Destinations.Main.route) }) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = null)
                }
            }
        )

        Column(
            modifier = Modifier.padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Question indicators
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                repeat(6) { index ->
                    Card(
                        border = BorderStroke(
                            width = if (question == index + 1) 2.dp else 0.dp,
                            color = questionColors[index]
                        ),
                        modifier = Modifier.aspectRatio(1f),
                        shape = CircleShape,
                        colors = CardDefaults.cardColors(contentColor = Color.Unspecified)
                    ) { }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                "تلفن همراه خود را ۳۰ سانتی متری چشمان خود قرار دهید و جهت E را مشخص کنید",
                textAlign = TextAlign.Center
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    modifier = Modifier
                        .scale(6f / question)
                        .rotate(rotation),
                    text = "E"
                )
            }

            // Directional buttons
            LazyVerticalGrid(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 100.dp, vertical = 30.dp),
                columns = GridCells.Fixed(3)
            ) {
                item {}
                item {
                    DirectionButton(
                        icon = Icons.Default.KeyboardArrowUp,
                        onClick = {
                            handleAnswer(rotation == 270f)
                        }
                    )
                }
                item {}
                item {
                    DirectionButton(
                        icon = Icons.Default.KeyboardArrowRight,
                        onClick = {
                            handleAnswer(rotation == 0f)
                        }
                    )
                }
                item {}
                item {
                    DirectionButton(
                        icon = Icons.Default.KeyboardArrowLeft,
                        onClick = {
                            handleAnswer(rotation == 180f)
                        }
                    )
                }
                item {}
                item {
                    DirectionButton(
                        icon = Icons.Default.KeyboardArrowDown,
                        onClick = {
                            handleAnswer(rotation == 90f)
                        }
                    )
                }
                item {}
            }
        }
    }
}

@Composable
fun DirectionButton(icon: ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier.aspectRatio(1f),
        shape = CircleShape,
        onClick = onClick
    ) {
        Icon(
            modifier = Modifier.fillMaxSize(),
            imageVector = icon,
            contentDescription = null
        )
    }
}
